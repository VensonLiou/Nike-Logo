import UIKit

let view = UIView(frame: CGRect(x: 0, y: 0, width: 500, height: 500))
let path = UIBezierPath()

view.backgroundColor = UIColor(displayP3Red: 237/255, green: 111/255, blue: 45/255, alpha: 1)


var point = CGPoint(x: 100, y: 180)
path.move(to: point)

point = CGPoint(x: 150, y: 290)
var controlPoint = CGPoint(x: -20, y: 350)
path.addQuadCurve(to: point, controlPoint: controlPoint)

point = CGPoint(x: 450, y: 180)
path.addLine(to: point)

point = CGPoint(x: 160, y: 250)
path.addLine(to: point)

point = CGPoint(x: 100, y: 180)
controlPoint = CGPoint(x: 60, y: 270)
path.addQuadCurve(to: point, controlPoint: controlPoint)

let nikeLayer = CAShapeLayer()
nikeLayer.path = path.cgPath
view.layer.mask = nikeLayer
view
